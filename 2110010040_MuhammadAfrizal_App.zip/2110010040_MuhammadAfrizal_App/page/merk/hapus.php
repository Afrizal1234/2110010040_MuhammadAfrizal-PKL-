<!-- <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script> -->

<?php
$id_merk = $_GET['id_merk'];
$sql = $con->query("DELETE FROM merk WHERE id_merk='$id_merk'");

if ($sql) { 
    echo "
    
    <script>
        setTimeout(function() {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data berhasil dihapus!',
                timer: 1700,
                showConfirmButton: false
            }).then(function() {
                window.location = '?page=merk';
            });
        }, 300);
    </script>";
} else { 
    echo " 
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Data gagal dihapus!',
        });
    </script>";
}
?>
