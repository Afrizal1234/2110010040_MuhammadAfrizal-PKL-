<!-- <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script> -->

<?php
$id_satuan = $_GET['id_satuan'];
$sql = $con->query("DELETE FROM satuan WHERE id_satuan='$id_satuan'");

if ($sql) { 
    echo "
    
    <script>
        setTimeout(function() {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data berhasil dihapus!',
                timer: 1700,
                showConfirmButton: false
            }).then(function() {
                window.location = '?page=satuan';
            });
        }, 300);
    </script>";
} else { 
    echo " 
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Data gagal dihapus!',
        });
    </script>";
}
?>
