<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>

<!--page title-->
<div class="page-title mb-4 d-flex align-items-center row">
    <div class="col-md-6 mb-2">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Tambah Data Satuan</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>
                <li class="breadcrumb-item"><a href="#">Data Master</a></li>
                <li class="breadcrumb-item"><a href="#">Satuan</a></li>
                <li class="breadcrumb-item active" aria-current="page">Tambah Data</li>
            </ol>
        </nav>
    </div> 
</div>
<!--/page title-->


<div class="tab-content" id="pills-tabContent">
    <div class="tab-pane fade show active" id="round-form" role="tabpanel" aria-labelledby="round-form-tab">
        <div class="row"> 
            <div class="col-md-12">
                <div class="card card-shadow mb-4">
                    <div class="card-header border-0">
                        <div class="custom-title-wrap bar-primary">
                            <div class="custom-title">Tambah Data Satuan</div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form enctype="multipart/form-data" method="post">
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Satuan</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="satuan" autofocus required >
                                </div>
                            </div>  
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">&nbsp;</label>
                                <div class="col-sm-9">
                                    <button name="simpan" class="btn btn-outline-primary rounded-0 btn-sm">Simpan</button>
                                    <a href="?page=satuan" class="btn btn-outline-warning rounded-0 btn-sm"> Kembali</a>
                                </div>
                            </div>
                        </form>
                        <?php 
                        if (isset($_POST['simpan'])) 
                        {
                            $satuan            = $_POST['satuan'];     
 
                            $ambil = $con->query("SELECT * FROM satuan WHERE satuan='$satuan'");
                            $yangcocok = mysqli_num_rows($ambil);
                            
                            if ($yangcocok==1) 
                            { 
                                echo " 
                                <script>
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Oops...',
                                        text: 'Satuan sudah ada!',
                                    }).then(function() {
                                        window.location = '?page=satuan&aksi=tambah';
                                    });
                                </script>";
                            }
                            else
                            { 
                                $con->query("INSERT INTO satuan (satuan) VALUES ('$satuan') ");
                                 
                                echo " 
                                <script>
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Berhasil!',
                                        text: 'Data berhasil disimpan!',
                                        timer: 1700,
                                        showConfirmButton: false
                                    }).then(function() {
                                        window.location = '?page=satuan';
                                    });
                                </script>";
                            }
                        }
                        ?>

                    </div>
                </div> 
            </div>
        </div>
    </div> 
</div> 