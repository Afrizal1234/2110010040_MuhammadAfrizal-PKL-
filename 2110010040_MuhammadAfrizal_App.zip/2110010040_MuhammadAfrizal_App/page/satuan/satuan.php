<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Satuan</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>
                <li class="breadcrumb-item"><a href="#">Data Master</a></li>
                <li class="breadcrumb-item active" aria-current="page">Satuan</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary">
                    <div class="custom-title">Data Satuan
                        <div class="float-right" style="vertical-align: top;">
                            <a href="?page=satuan&aksi=tambah" class="btn btn-outline-primary rounded-0 btn-sm" data-toggle="tooltip" data-placement="top" title="Tambah data"><i class="ti-plus"></i></a>  
                        </div>
                    </div>                    
                </div>
            </div>
            <div class="card-body- pt-3 pb-4">
                <div class="table-responsive">
                    <table id="data_table" class="table table-bordered table-striped" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="3%">No.</th>
                                <th>Satuan</th> 
                                <th width="15%" class="text-center">#</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $nomor=1; ?>
                            <?php $ambil=$con->query("SELECT * FROM satuan ORDER BY id_satuan ASC"); ?>
                            <?php while ($pecah = $ambil->fetch_assoc()) { 
                                // $tgl = tgl_indo($pecah['tgl']); ?>
                            <tr> 
                                <td class="text-center"><?php echo $nomor; ?></td>  
                                <td><?php echo $pecah['satuan']; ?></td>        
                                <td class="text-center"> 
                                    <a href="?page=satuan&aksi=ubah&id_satuan=<?php echo $pecah['id_satuan'] ?>" data-toggle="tooltip" data-placement="top" title="Ubah data" class="btn btn-outline-success rounded-0 btn-sm"><i class="ti-pencil"></i></a> 
                                    <a onclick="confirmDelete(<?php echo $pecah['id_satuan']; ?>)" data-toggle="tooltip" data-placement="top" title="Hapus data" class="btn btn-outline-danger rounded-0 btn-sm"><i class="ti-trash"></i></a>
                                </td> 
                            </tr> 
                            <?php $nomor++; ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 

<script>
function confirmDelete(id_satuan) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Anda tidak bisa mengembalikan data yang telah dihapus!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "?page=satuan&aksi=hapus&id_satuan=" + id_satuan;
        }
    });
}
</script>