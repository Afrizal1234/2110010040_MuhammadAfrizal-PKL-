
<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Laporan Barang Keluar</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>  
                <li class="breadcrumb-item active" aria-current="page">Permintaan</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary"> 
                    <div class="custom-title">Laporan Barang Keluar
                        <code>(Filter Berdasarkan Periode Tanggal Keluar)</code>
                    </div>             
                </div>
            </div>
            <div class="card-body pt-3 pb-4">
                <div class="table-responsive">
                    <div class="row">
                        <div class="col-md-7"></div>
                        <div class="col-md-5">
                            <form method="post">
                                <div class="form-row align-items-center">
                                    <div class="col">
                                        <label class="sr-only">Dari Tanggal</label>
                                        <input type="date" class="form-control mb-2" name="tgl_awal" placeholder="Dari Tanggal" required>
                                    </div>
                                    <div class="col">
                                        <label class="sr-only">Sampai Tanggal</label>
                                        <input type="date" class="form-control mb-2" name="tgl_akhir" placeholder="Sampai Tanggal" required>
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" name="cari" class="btn btn-info mb-2">Lihat</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <?php  
                    if (!empty($_POST['tgl_awal']) && !empty($_POST['tgl_akhir'])) {
                        $tgl_awal = $_POST['tgl_awal'];
                        $tgl_akhir = $_POST['tgl_akhir'];
                        echo "<div class='alert alert-info'>Menampilkan data barang keluar dari tanggal keluar barang <strong>" . tgl_indo($tgl_awal) . "</strong> sampai <strong>" . tgl_indo($tgl_akhir) . "</strong></div>";
                    } else {
                        echo "<div class='alert alert-warning'>Tanggal barang keluar belum dipilih.</div>";
                    }
                    ?>

                    <table class="table table-bordered table-striped" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="3%" class="text-center" rowspan="2" style="vertical-align: middle;">No.</th>
                                <th rowspan="2" class="text-center" style="vertical-align: middle;">Nota</th>
                                <th colspan="3" class="text-center">Permintaan</th> 
                                <th colspan="6" class="text-center">Keluar</th>   
                            </tr>
                            <tr>
                                <th class="text-center">Hari, Tanggal</th> 
                                <th class="text-center">Dari</th>
                                <th class="text-center">Unit Kerja</th>
                                <th class="text-center">Hari, Tanggal</th> 
                                <th class="text-center">Dikeluarkan</th>
                                <th>Barang</th>
                                <th class="text-center">Harga</th>
                                <th class="text-center">Qty</th>
                                <th class="text-right">Sub Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php  
                            $tgl_awal = isset($_POST['tgl_awal']) ? $_POST['tgl_awal'] : '';
                            $tgl_akhir = isset($_POST['tgl_akhir']) ? $_POST['tgl_akhir'] : ''; 

                            $nomor = 1; 
                            $gtotal = 0;  
 
                            $query = "SELECT * FROM minta WHERE status='Sudah diambil'";
 
                            if (!empty($tgl_awal) && !empty($tgl_akhir)) {
                                $query .= " AND tgl_keluar BETWEEN '$tgl_awal' AND '$tgl_akhir'"; 
                            }  

                            $query .= " ORDER BY nomor ASC";
                            $ambil = $con->query($query);
 
                            if (!$ambil) {
                                die("Query error: " . $con->error);  
                            }

                            while ($pecah = $ambil->fetch_assoc()) {
                                $tgl = tgl_indo($pecah['tanggal']);
                                $tgl1 = tgl_indo($pecah['tgl_keluar']);
                                ?> 
                                <tr> 
                                    <td class="text-center"><?php echo $nomor; ?></td>  
                                    <td class="text-center"><?php echo $pecah['nomor']; ?></td>    
                                    <td class="text-center"><?php echo $pecah['hari']; ?>, <?php echo $tgl; ?></td>    
                                    <td class="text-center"><?php echo $pecah['dari_nama']; ?></td>      
                                    <td class="text-center"><?php echo $pecah['dari_unit']; ?></td>   
                                    <td class="text-center"><?php echo $pecah['hari_keluar']; ?>, <?php echo $tgl1; ?></td>     
                                    <td class="text-center">
                                        <?php 
                                        $sql_barang = mysqli_query($con, "SELECT DISTINCT dikeluarkan FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                        while ($data_barang = mysqli_fetch_array($sql_barang)) { 
                                            echo $data_barang['dikeluarkan']." "; 
                                        } 
                                        ?>
                                    </td>    
                                    <td>
                                        <?php 
                                        $sql_barang = mysqli_query($con, "SELECT * FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                        while ($data_barang = mysqli_fetch_array($sql_barang)) { 
                                            echo $data_barang['nama_barang']."<br>"; 
                                        } 
                                        ?>
                                    </td>   
                                    <td class="text-center">
                                        <?php 
                                        $sql_barang = mysqli_query($con, "SELECT * FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                        while ($data_barang = mysqli_fetch_array($sql_barang)) { 
                                            echo number_format($data_barang['harga_barang'], 0, ',','.')."<br>";
                                        } 
                                        ?>
                                    </td>  
                                    <td class="text-center">
                                        <?php 
                                        $sql_barang = mysqli_query($con, "SELECT * FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                        while ($data_barang = mysqli_fetch_array($sql_barang)) { 
                                            echo $data_barang['qty']."<br>";
                                        } 
                                        ?>
                                    </td>  
                                    <td class="text-right">
                                        <?php 
                                        $sql_barang = mysqli_query($con, "SELECT * FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                        while ($data_barang = mysqli_fetch_array($sql_barang)) { 
                                            $sub_total = $data_barang['harga_barang'] * $data_barang['qty']; 
                                            echo number_format($sub_total, 0, ',','.')."<br>";
                                            $gtotal += $sub_total;  
                                        } 
                                        ?>
                                    </td>         
                                </tr> 
                                <?php $nomor++; ?>
                            <?php } ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="10" class="text-center">Grand Total</th>
                                <th class="text-right"><?php echo number_format($gtotal, 0, ',', '.'); ?></th>  
                            </tr>
                        </tfoot>
                    </table>
                    <p>
                        <a href="page/laporan/barang_keluar_periode.php?tgl_awal=<?php echo $tgl_awal; ?>&tgl_akhir=<?php echo $tgl_akhir; ?>" 
                           <?php if (!empty($tgl_awal) && !empty($tgl_akhir)) { echo 'target="_blank"'; } ?> 
                           class="btn btn-primary btn-sm">Cetak</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>  
