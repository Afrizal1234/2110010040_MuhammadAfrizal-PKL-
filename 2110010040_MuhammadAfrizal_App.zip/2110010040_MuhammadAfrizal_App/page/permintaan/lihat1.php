<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
<!--page title-->
<div class="page-title mb-4 d-flex align-items-center row">
    <div class="col-md-6 mb-2">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Pengambilan Barang</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li> 
                <li class="breadcrumb-item"><a href="#">Permintaan</a></li>
                <li class="breadcrumb-item active" aria-current="page">Pengambilan Barang</li>
            </ol>
        </nav>
    </div> 
</div>
<!--/page title-->

<?php
$nomor = $_GET['nomor'];
$sql = $con->query("SELECT * FROM minta NATURAL JOIN minta_detail WHERE nomor='$nomor'");
$pecah = mysqli_fetch_assoc($sql);
$tgl = tgl_indo($pecah['tanggal']);
$tgl2 = tgl_indo($pecah['tgl_keluar']);
?>

<div class="row">
    <div class="col-12">
        <div class="card card-shadow mb-4 p-md-5">
            <div class="card-body">
                 <div class="row py-4"> 
                    <div class="col-sm-4"> 
                         <address>
                             <strong>Dari :</strong>
                             <br> <span class="text-muted">Nama : <?php echo $pecah['dari_nama'] ?></span>
                             <br> <span class="text-muted">Unit Kerja : <?php echo $pecah['dari_unit'] ?></span>
                         </address>
                    </div>
                 </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="row mb-5">
                            <div class="col-4">
                                <small class="text-muted text-uppercase weight600">Hari, Tanggal Permintaan</small>
                                <h5 class="mb-0"><?php echo $pecah['hari'] ?>, <?php echo $tgl ?></h5>
                            </div> 
                            <div class="col-4">
                                <small class="text-muted text-uppercase weight600">Total</small>
                                <h5 class="mb-0"><?php echo number_format($pecah['gtotal'], 0, ',','.') ?></h5>
                            </div>
                            <div class="col-4">
                                <small class="text-muted text-uppercase weight600">Status</small>
                                <h5 class="mb-0"><?php echo $pecah['status'] ?></h5>
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="text-center" width="3%">No</th> 
                                        <th>Barang</th> 
                                        <th class="text-center">Jumlah</th> 
                                        <th class="text-center">Merk</th> 
                                        <th class="text-center">Satuan</th> 
                                        <th class="text-center">Kategori</th>  
                                        <th class="text-right">Harga</th>  
                                        <th class="text-right">Sub Total</th>   
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no= 1;
                                        $gtotal = 0;  
                                        $sqltampil = mysqli_query($con, "SELECT * FROM minta_detail
                                            NATURAL JOIN barang NATURAL JOIN merk NATURAL JOIN satuan NATURAL JOIN kategori WHERE nomor='$nomor'");
                                        while ($data = mysqli_fetch_assoc($sqltampil)){
                                            $stotal = $data['qty'] * $data['harga_barang']; 
                                            $gtotal += $stotal; 
                                    ?>
                                    <tr>
                                        <td class="text-center"><?php echo $no++; ?></td> 
                                        <td><?php echo $data['nama_barang'] ?></td> 
                                        <td class="text-center"><?php echo $data['qty'] ?></td> 
                                        <td class="text-center"><?php echo $data['merk'] ?></td> 
                                        <td class="text-center"><?php echo $data['satuan'] ?></td> 
                                        <td class="text-center"><?php echo $data['kategori'] ?></td>  
                                        <td class="text-right"><?php echo number_format($data['harga_barang'], 0, ',','.') ?></td>  
                                        <td class="text-right"><?php echo number_format($stotal, 0, ',','.') ?></td>   
                                    </tr> 
                                    <?php
                                        } 
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="7" class="text-center">Total</th>
                                        <td class="text-right"><?php echo number_format($gtotal, 0, ',','.') ?></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>  

                    </div> 
                </div>
            </div> 
            <div class="row"> 
                <div class="col-md-4 text-center">
                    <p style="line-height: 6px;">Mengetahui,</p>
                    <p style="line-height: 6px;">kasubbag Sekretariat & Rumah Tangga</p>
                    <br><br><br>
                    <p><b><u>Mohammad Aulia Rahman, S.Kom</u></b></p> 
                </div>
                <div class="col-md-4 text-center">
                    <p style="line-height: 6px;">&nbsp;</p>
                    <p style="line-height: 6px;">Petugas Koperasi</p>
                    <br><br><br>
                    <p><b><u><?php echo $pecah['dikeluarkan'] ?></u></b></p>
                </div>
                <div class="col-md-4 text-center">
                    <p style="line-height: 6px;">Banjarbaru, <?php echo $tgl2 ?></p>
                    <p style="line-height: 6px;">Di Terima Oleh:</p>
                    <br><br><br>
                    <p><b><u><?php echo $pecah['diambil'] ?></u></b></p>
                </div>
            </div>
        </div> 
    </div>
</div>
