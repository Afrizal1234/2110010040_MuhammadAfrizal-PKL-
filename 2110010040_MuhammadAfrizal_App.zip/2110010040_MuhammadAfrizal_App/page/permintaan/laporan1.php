<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Laporan Permintaan Barang</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>  
                <li class="breadcrumb-item active" aria-current="page">Barang</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary">
                    <div class="custom-title">Laporan Permintaan Barang <code>(Filter Berdasarkan Periode Tanggal Permintaan)</code></div>               
                </div>
            </div>
            <div class="card-body pt-3 pb-4">
                <div class="table-responsive">
                    <div class="row">
                        <div class="col-md-7"></div>
                        <div class="col-md-5">
                            <form method="post">
                                <div class="form-row align-items-center">
                                    <div class="col">
                                        <label class="sr-only">Dari Tanggal</label>
                                        <input type="date" class="form-control mb-2" name="tgl_awal" placeholder="Dari Tanggal" required>
                                    </div>
                                    <div class="col">
                                        <label class="sr-only">Sampai Tanggal</label>
                                        <input type="date" class="form-control mb-2" name="tgl_akhir" placeholder="Sampai Tanggal" required>
                                    </div>
                                    <div class="col-auto">
                                        <button type="submit" name="cari" class="btn btn-info mb-2">Lihat</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php  
                    if (!empty($_POST['tgl_awal']) && !empty($_POST['tgl_akhir'])) {
                        $tgl_awal = $_POST['tgl_awal'];
                        $tgl_akhir = $_POST['tgl_akhir'];
                        echo "<div class='alert alert-info'>Menampilkan data permintaan dari tanggal permintaan barang <strong>" . tgl_indo($tgl_awal) . "</strong> sampai <strong>" . tgl_indo($tgl_akhir) . "</strong></div>";
                    } else {
                        echo "<div class='alert alert-warning'>Tanggal permintaan belum dipilih.</div>";
                    }
                    ?>
                    <table class="table table-bordered table-striped" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="3%">No.</th>
                                <th>Nota</th>
                                <th>Hari, Tanggal</th>
                                <th>Dari</th> 
                                <th>Unit Kerja</th> 
                                <th class="text-center">Status</th> 
                                <th class="text-right">Total</th> 
                            </tr>
                        </thead>
                        <tbody>
                            <?php  
                            $tgl_awal = isset($_POST['tgl_awal']) ? $_POST['tgl_awal'] : '';
                            $tgl_akhir = isset($_POST['tgl_akhir']) ? $_POST['tgl_akhir'] : ''; 

                            $nomor = 1; 
                            $query = "SELECT * FROM minta";
                             
                            if (!empty($tgl_awal) && !empty($tgl_akhir)) {
                                $query .= " WHERE tanggal BETWEEN '$tgl_awal' AND '$tgl_akhir'"; 
                            }  

                            $query .= " ORDER BY nomor ASC";
                            $ambil = $con->query($query);
                            while ($pecah = $ambil->fetch_assoc()) {
                                $tgl = tgl_indo($pecah['tanggal']);
                            ?>
                                <tr> 
                                    <td><?php echo $nomor; ?></td>  
                                    <td><?php echo $pecah['nomor']; ?></td>    
                                    <td><?php echo $pecah['hari']; ?>, <?php echo $tgl; ?></td>    
                                    <td><?php echo $pecah['dari_nama']; ?></td>      
                                    <td><?php echo $pecah['dari_unit']; ?></td>      
                                    <td class="text-center"><?php echo $pecah['status']; ?></td>       
                                    <td class="text-right"><?php echo number_format($pecah['gtotal'], 0, ',','.') ?></td> 
                                </tr> 
                            <?php
                                $nomor++;
                            }
                            ?>
                        </tbody>
                    </table>
                    <p>                        
                        <a href="page/laporan/permintaan_periode.php?tgl_awal=<?php echo $tgl_awal; ?>&tgl_akhir=<?php echo $tgl_akhir; ?>" 
                           <?php if (!empty($tgl_awal) && !empty($tgl_akhir)) { echo 'target="_blank"'; } ?> 
                           class="btn btn-primary btn-sm">Cetak</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
