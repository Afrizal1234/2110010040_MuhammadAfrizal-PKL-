
<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Laporan Barang Yang Sering Keluar</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>  
                <li class="breadcrumb-item active" aria-current="page">Permintaan</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary"> 
                    <div class="custom-title">Laporan Barang Yang Sering Keluar
                        
                    </div>             
                </div>
            </div>
            <div class="card-body pt-3 pb-4">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="3%">No.</th>
                                <th>Kode</th>
                                <th>Nama Barang</th>
                                <th class="text-center">Merk</th>
                                <th class="text-center">Kategori</th>
                                <th class="text-center">Bulan</th>
                                <th class="text-center">Tahun</th>
                                <th class="text-center">Jumlah Keluar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $nomor = 1;  
                            $ambil = $con->query("
                                SELECT 
                                    b.kode AS kode,
                                    b.nama AS nama,
                                    m.merk AS merk,
                                    k.kategori AS kategori,
                                    MONTH(minta.tgl_keluar) AS bulan,
                                    YEAR(minta.tgl_keluar) AS tahun,
                                    SUM(md.qty) AS jumlah_keluar
                                FROM 
                                    minta_detail md
                                JOIN 
                                    barang b ON md.id_barang = b.id_barang
                                JOIN 
                                    merk m ON b.id_merk = m.id_merk
                                JOIN 
                                    kategori k ON b.id_kategori = k.id_kategori
                                JOIN 
                                    minta ON md.nomor = minta.nomor
                                WHERE 
                                    minta.status = 'Sudah diambil'
                                GROUP BY 
                                    b.kode, b.nama, m.merk, k.kategori, MONTH(minta.tgl_keluar), YEAR(minta.tgl_keluar)
                                ORDER BY 
                                    jumlah_keluar DESC
                            ");
                             
                            while ($pecah = $ambil->fetch_assoc()) { 
                                $bln = getBulan($pecah['bulan']);
                            ?>
                                <tr> 
                                    <td class="text-center"><?php echo $nomor; ?></td>  
                                    <td><?php echo $pecah['kode']; ?></td>    
                                    <td><?php echo $pecah['nama']; ?></td>    
                                    <td class="text-center"><?php echo $pecah['merk']; ?></td>      
                                    <td class="text-center"><?php echo $pecah['kategori']; ?></td>      
                                    <td class="text-center"><?php echo $bln; ?></td>       
                                    <td class="text-center"><?php echo $pecah['tahun']; ?></td> 
                                    <td class="text-center"><?php echo number_format($pecah['jumlah_keluar'], 0, ',', '.'); ?></td>
                                </tr> 
                            <?php 
                                $nomor++;
                            } 
                            ?>
                        </tbody>
                    </table> 
                    <p>
                        <a href="page/laporan/sering_keluar.php" class="btn btn-sm btn-primary" target="_blank">Cetak</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>  
