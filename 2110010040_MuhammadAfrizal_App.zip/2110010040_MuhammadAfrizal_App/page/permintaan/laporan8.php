
<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Laporan Grafik Barang Keluar</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>  
                <li class="breadcrumb-item active" aria-current="page">Permintaan</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary"> 
                    <div class="custom-title">Laporan Grafik Barang Keluar
                        
                    </div>             
                </div>
            </div>
            <div class="card-body pt-3 pb-4">
                <div class="table-responsive">
                    <div class="row">
                        <div class="col-md-12">
                            <form method="POST" action="" >
                                <div class="form-row">
                                    <div class="col-6"> 
                                        <select name="bulan_trend" id="bulan" class="form-control">
                                            <?php 
                                            for ($i = 1; $i <= 12; $i++) {
                                                $selected = (isset($_POST['bulan_trend']) && $_POST['bulan_trend'] == $i) ? 'selected' : '';
                                                echo "<option value='$i' $selected>" . date('F', mktime(0, 0, 0, $i, 1)) . "</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col"> 
                                        <select name="tahun_trend" id="tahun" class="form-control">
                                            <?php
                                            $currentYear = date("Y");
                                            for ($i = $currentYear; $i >= $currentYear - 5; $i--) {
                                                $selected = (isset($_POST['tahun_trend']) && $_POST['tahun_trend'] == $i) ? 'selected' : '';
                                                echo "<option value='$i' $selected>$i</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col">
                                        <button type="submit" name="filter_trend" class="btn btn-info mb-2">Lihat</button>
                                    </div> 
                                </div>                                
                            </form>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <?php 
                                if (isset($_POST['filter_trend'])) {
                                    $bulan = $_POST['bulan_trend'];
                                    $tahun = $_POST['tahun_trend'];
                                } else { 
                                    $bulan = date('n');  
                                    $tahun = date('Y'); 
                                }
 
                                $query = "
                                    SELECT 
                                        b.kode AS kode,
                                        b.nama AS nama,
                                        SUM(md.qty) AS jumlah_keluar
                                    FROM 
                                        minta_detail md
                                    JOIN 
                                        barang b ON md.id_barang = b.id_barang
                                    JOIN 
                                        minta ON md.nomor = minta.nomor
                                    WHERE 
                                        minta.status = 'Sudah diambil'
                                ";
 
                                $query .= " AND MONTH(minta.tgl_keluar) = '$bulan' AND YEAR(minta.tgl_keluar) = '$tahun'";
 
                                $query .= " GROUP BY b.kode, b.nama ORDER BY jumlah_keluar DESC";

                                $ambil = $con->query($query);
 
                                $data_barang = [];
                                $data_jumlah_keluar = [];
                                $info_barang = '';
                                while ($row = $ambil->fetch_assoc()) {
                                    $data_barang[] = $row['nama'];
                                    $data_jumlah_keluar[] = (int)$row['jumlah_keluar'];
                                     
                                    $info_barang .= "<p><strong>" . htmlspecialchars($row['nama']) . "</strong> (Kode: " . htmlspecialchars($row['kode']) . ") - Jumlah Keluar: " . (int)$row['jumlah_keluar'] . "</p>";
                                } 
                                ?>
 
                                    <div id="grafikBarangKeluar"></div> 
                          
                                 
                                <script src="https://code.highcharts.com/modules/exporting.js"></script>
                                <script>
                                    document.addEventListener('DOMContentLoaded', function () {
                                        Highcharts.chart('grafikBarangKeluar', {
                                            chart: {
                                                type: 'pie',
                                                options3d: {
                                                    enabled: true,
                                                    alpha: 45,
                                                    beta: 0
                                                }
                                            },
                                            title: {
                                                text: '<?php echo 'Grafik Data Barang Keluar Bulan ' . getBulan($bulan) . ' ' . $tahun; ?>'
                                            },
                                            tooltip: {
                                                pointFormat: '<b>{point.name}</b>: Jumlah Keluar {point.y} (Kode: {point.kode})',
                                                useHTML: true
                                            },
                                            plotOptions: {
                                                pie: {
                                                    innerSize: '30%',  
                                                    depth: 45,  
                                                    dataLabels: {
                                                        enabled: true,
                                                        format: '{point.name}: {point.y}',  
                                                        style: {
                                                            fontWeight: 'bold',
                                                            color: 'black'  
                                                        }
                                                    }
                                                }
                                            },
                                            series: [{
                                                name: 'Jumlah',
                                                data: <?php 
                                                    $data_for_chart = [];
                                                    $ambil->data_seek(0);  
                                                    while ($row = $ambil->fetch_assoc()) {
                                                        $data_for_chart[] = [
                                                            'name' => $row['nama'],
                                                            'y' => (int)$row['jumlah_keluar'],
                                                            'kode' => $row['kode']  
                                                        ];
                                                    }
                                                    echo json_encode($data_for_chart); 
                                                ?>,
                                                colorByPoint: true  
                                            }]
                                        });
                                    });
                                </script> 
                            </div>
                        </div>
                    </div>
                    <p>
                        <a href="page/laporan/grafik.php?bulan=<?php echo $bulan; ?>&tahun=<?php echo $tahun; ?>" 
                           <?php if (!empty($bulan) && !empty($tahun)) { echo 'target="_blank"'; } ?> 
                           class="btn btn-primary btn-sm">Cetak</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>  
