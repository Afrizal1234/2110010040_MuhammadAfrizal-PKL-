<?php 
$today = date('Y/m-');
$char = '' . $today;
$query = mysqli_query($con, "SELECT max(nomor) as max_id FROM minta WHERE nomor LIKE '{$char}%' ORDER BY nomor DESC LIMIT 1");
$data = mysqli_fetch_assoc($query);
$getId = $data['max_id']; 
$no = substr($getId, -4, 4); 
$no = (int) $no; 
$no += 1; 
$nomor = $char . sprintf("%04s", $no); 
?>


<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Permintaan</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li> 
                <li class="breadcrumb-item active" aria-current="page">Permintaan</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary">
                    <div class="custom-title">Data Permintaan
                        <div class="float-right" style="vertical-align: top;">
                            <?php if ($_SESSION['kasubbag']) { ?>
                            <a href="?page=permintaan&aksi=tambah&nomor=<?php echo $nomor; ?>" class="btn btn-outline-primary rounded-0 btn-sm" data-toggle="tooltip" data-placement="top" title="Tambah data"><i class="ti-plus"></i></a>  
                            <?php } ?>
                        </div>
                    </div>                    
                </div>
            </div>
            <div class="card-body- pt-3 pb-4">
                <div class="table-responsive">
                    <table id="data_table" class="table table-bordered table-striped" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="3%">No.</th>
                                <th>Nota</th>
                                <th>Hari, Tanggal</th>
                                <th>Dari</th> 
                                <th>Unit Kerja</th> 
                                <th class="text-center">Status</th> 
                                <th class="text-right">Total</th>
                                <th class="text-center" width="15%">#</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $nomor=1; ?>
                            <?php $ambil=$con->query("SELECT * FROM minta ORDER BY nomor ASC"); ?>
                            <?php while ($pecah = $ambil->fetch_assoc()) { 
                                $tgl = tgl_indo($pecah['tanggal']); ?>
                            <tr> 
                                <td><?php echo $nomor; ?></td>  
                                <td><?php echo $pecah['nomor']; ?></td>    
                                <td><?php echo $pecah['hari']; ?>, <?php echo $tgl; ?></td>    
                                <td><?php echo $pecah['dari_nama']; ?></td>      
                                <td><?php echo $pecah['dari_unit']; ?></td>      
                                <td class="text-center"><?php echo $pecah['status']; ?></td>       
                                <td class="text-right"><?php echo number_format($pecah['gtotal'], 0, ',','.') ?></td>
                                <?php if ($_SESSION['Koperasi'] || $_SESSION['kasubbag'] || $_SESSION['Sekretariat']) { ?>       
                                <td class="text-center"> 
                                    <?php if($pecah['status'] == 'Pending'){ ?>  
                                        <a href="?page=permintaan&aksi=lihat&nomor=<?php echo $pecah['nomor'] ?>" data-toggle="tooltip" data-placement="top" title="Lihat data" class="btn btn-outline-warning rounded-0 btn-sm"><i class="ti-eye"></i></a> 
                                    <?php } ?>
                                    <?php if($pecah['status'] == 'Approve, Sekretariat'){ ?>  
                                        <a href="?page=permintaan&aksi=lihat&nomor=<?php echo $pecah['nomor'] ?>" data-toggle="tooltip" data-placement="top" title="Lihat data" class="btn btn-outline-warning rounded-0 btn-sm"><i class="ti-eye"></i></a> 
                                    <?php } ?>
                                    <?php if ($_SESSION['Koperasi']) { ?>
                                    <?php if($pecah['status'] == 'Approve, Sekretariat'){ ?>   
                                        <a href="?page=permintaan&aksi=keluar&nomor=<?php echo $pecah['nomor'] ?>" data-toggle="tooltip" data-placement="top" title="Keluarkan" class="btn btn-outline-success rounded-0 btn-sm"><i class="ti-pencil"></i></a>  
                                    <?php }} ?>

                                    <?php if($pecah['status'] == 'Sudah diambil'){ ?>
                                        <a href="?page=permintaan&aksi=lihat1&nomor=<?php echo $pecah['nomor'] ?>" data-toggle="tooltip" data-placement="top" title="Lihat data" class="btn btn-outline-warning rounded-0 btn-sm"><i class="ti-eye"></i></a>  
                                        <a href="cetak_spengantar.php?nomor=<?php echo $pecah['nomor'] ?>" target="_blank" data-toggle="tooltip" data-placement="top" title="Cetak Surat Pengantar" class="btn btn-outline-primary rounded-0 btn-sm"><i class="ti-email"></i></a>  
                                    <?php } ?>
                                </td> 
                                <?php } ?>
                                
                            </tr> 
                            <?php $nomor++; ?>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div> 

<script>
function confirmDelete(id_barang) {
    Swal.fire({
        title: 'Apakah Anda yakin?',
        text: "Anda tidak bisa mengembalikan data yang telah dihapus!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya, hapus!',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "?page=barang&aksi=hapus&id_barang=" + id_barang;
        }
    });
}
</script>