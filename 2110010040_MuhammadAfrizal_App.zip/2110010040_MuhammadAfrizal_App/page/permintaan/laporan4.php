
<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Laporan Barang Keluar</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>  
                <li class="breadcrumb-item active" aria-current="page">Permintaan</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary"> 
                    <div class="custom-title">Laporan Barang Keluar
                        
                    </div>             
                </div>
            </div>
            <div class="card-body pt-3 pb-4">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="3%" class="text-center" rowspan="2" style="vertical-align: middle;">No.</th>
                                <th rowspan="2" class="text-center" style="vertical-align: middle;">Nota</th>
                                <th colspan="3" class="text-center">Permintaan</th> 
                                <th colspan="6" class="text-center">Keluar</th>   
                            </tr>
                            <tr>
                                <th class="text-center">Hari, Tanggal</th> 
                                <th class="text-center">Dari</th>
                                <th class="text-center">Unit Kerja</th>
                                <th class="text-center">Hari, Tanggal</th> 
                                <th class="text-center">Dikeluarkan</th>
                                <th>Barang</th>
                                <th class="text-center">Harga</th>
                                <th class="text-center">Qty</th>
                                <th class="text-right">Sub Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $nomor = 1; 
                            $gtotal = 0;  
                            $ambil = $con->query("SELECT * FROM minta WHERE status='Sudah diambil' ORDER BY nomor ASC"); 
                            while ($pecah = $ambil->fetch_assoc()) { 
                                $tgl = tgl_indo($pecah['tanggal']); 
                                $tgl1 = tgl_indo($pecah['tgl_keluar']); ?>
                            <tr> 
                                <td class="text-center"><?php echo $nomor; ?></td>  
                                <td class="text-center"><?php echo $pecah['nomor']; ?></td>    
                                <td class="text-center"><?php echo $pecah['hari']; ?>, <?php echo $tgl; ?></td>    
                                <td class="text-center"><?php echo $pecah['dari_nama']; ?></td>      
                                <td class="text-center"><?php echo $pecah['dari_unit']; ?></td>   
                                <td class="text-center"><?php echo $pecah['hari_keluar']; ?>, <?php echo $tgl1; ?></td>     
                                <td class="text-center">
                                    <?php 
                                    $sql_barang = mysqli_query($con, "SELECT DISTINCT dikeluarkan FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                    while ($data_barang = mysqli_fetch_array($sql_barang)){ 
                                        echo $data_barang['dikeluarkan']." "; 
                                    } 
                                    ?>
                                </td>    
                                <td>
                                    <?php 
                                    $sql_barang = mysqli_query($con, "SELECT * FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                    while ($data_barang = mysqli_fetch_array($sql_barang)){ 
                                        echo $data_barang['nama_barang']."<br>"; 
                                    } 
                                    ?>
                                </td>   
                                <td class="text-center">
                                    <?php 
                                    $sql_barang = mysqli_query($con, "SELECT * FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                    while ($data_barang = mysqli_fetch_array($sql_barang)){ 
                                        echo number_format($data_barang['harga_barang'], 0, ',','.')."<br>";
                                    } 
                                    ?>
                                </td>  
                                <td class="text-center">
                                    <?php 
                                    $sql_barang = mysqli_query($con, "SELECT * FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                    while ($data_barang = mysqli_fetch_array($sql_barang)){ 
                                        echo $data_barang['qty']."<br>";
                                    } 
                                    ?>
                                </td>  
                                <td class="text-right">
                                    <?php 
                                    $sql_barang = mysqli_query($con, "SELECT * FROM minta_detail WHERE nomor = '$pecah[nomor]'");
                                    while ($data_barang = mysqli_fetch_array($sql_barang)){ 
                                        $sub_total = $data_barang['harga_barang'] * $data_barang['qty']; 
                                        echo number_format($sub_total, 0, ',','.')."<br>";
                                        $gtotal += $sub_total;  
                                    } 
                                    ?>
                                </td>         
                            </tr> 
                            <?php $nomor++; ?>
                            <?php } ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th colspan="10" class="text-center">Grand Total</th>
                                <th class="text-right"><?php echo number_format($gtotal, 0, ',', '.'); ?></th>  
                            </tr>
                        </tfoot>
                    </table>

                    <p>
                        <a href="page/laporan/barang_keluar.php" class="btn btn-sm btn-primary" target="_blank">Cetak</a>
                    </p> 
                </div>
            </div>
        </div>
    </div>
</div>  
