<?php
	
	$qty = $_GET['qty'];
	$nomor = $_GET['nomor'];  
	$id_minta_detail = $_GET['id_minta_detail']; 
	$id_barang = $_GET['id_barang'];


	$sql = mysqli_query($con, "DELETE FROM minta_detail WHERE id_minta_detail='$id_minta_detail'");
	$sql1 = mysqli_query($con, "UPDATE barang SET stok=(stok + $qty) WHERE id_barang='$id_barang'");

	if ($sql || $sql1) 
	{
		?>
		<script>
			window.location.href="?page=permintaan&aksi=ibarang&nomor=<?php echo $nomor ?>";
		</script>
		<?php
	}

?> 