<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Laporan Permintaan Barang</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>  
                <li class="breadcrumb-item active" aria-current="page">Barang</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary">
                    <div class="custom-title">Laporan Permintaan Barang <code>(Filter Berdasarkan Unit Kerja)</code></div>               
                </div>
            </div>
            <div class="card-body pt-3 pb-4">
                <div class="table-responsive">
                    <div class="row">
                        <div class="col-md-7"></div>
                        <div class="col-md-5">
                            <form enctype="multipart/form-data" method="post">
                                <div class="form-group row"> 
                                    <div class="col-sm-10">
                                        <select class="form-control" name="dari_unit">
                                            <option selected disabled></option>
                                            <?php
                                            $sql_kat = mysqli_query($con, "SELECT DISTINCT dari_unit FROM minta");
                                            while ($kat = mysqli_fetch_array($sql_kat)) {
                                                echo "<option value='$kat[dari_unit]'>$kat[dari_unit]</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-2">
                                        <button type="submit" name="cari" class="btn btn-sm btn-info">Lihat</button>
                                    </div>
                                </div> 
                            </form>
                        </div>
                    </div>
                    <?php  
                    if (!empty($_POST['dari_unit'])) {
                        $dari_unit = $_POST['dari_unit']; 
                        echo "<div class='alert alert-info'>Menampilkan data permintaan barang berdasarkan unit kerja <strong>" . $dari_unit . "</strong></div>";
                    } else {
                        echo "<div class='alert alert-warning'>Unit kerja belum dipilih.</div>";
                    }
                    ?>
                    <table class="table table-bordered table-striped" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="3%">No.</th>
                                <th>Nota</th>
                                <th>Hari, Tanggal</th>
                                <th>Dari</th> 
                                <th>Unit Kerja</th> 
                                <th class="text-center">Status</th> 
                                <th class="text-right">Total</th> 
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $selected_dari_unit = isset($_POST['dari_unit']) ? $_POST['dari_unit'] : '';

                            $nomor = 1;
                            $query = "SELECT * FROM minta";
                            if (!empty($selected_dari_unit)) {
                                $query .= " WHERE dari_unit='$selected_dari_unit'";
                            }
                            $query .= " ORDER BY nomor ASC";
                            $ambil = $con->query($query);
                            while ($pecah = $ambil->fetch_assoc()) {
                                $tgl = tgl_indo($pecah['tanggal']);
                            ?>
                                <tr> 
                                    <td><?php echo $nomor; ?></td>  
                                    <td><?php echo $pecah['nomor']; ?></td>    
                                    <td><?php echo $pecah['hari']; ?>, <?php echo $tgl; ?></td>    
                                    <td><?php echo $pecah['dari_nama']; ?></td>      
                                    <td><?php echo $pecah['dari_unit']; ?></td>      
                                    <td class="text-center"><?php echo $pecah['status']; ?></td>       
                                    <td class="text-right"><?php echo number_format($pecah['gtotal'], 0, ',','.') ?></td> 
                                </tr> 
                            <?php
                                $nomor++;
                            }
                            ?>
                        </tbody>
                    </table>
                    <p>                        
                        <a href="page/laporan/permintaan_unit.php?dari_unit=<?php echo $selected_dari_unit; ?>" target="<?php echo !empty($selected_dari_unit) ? '_blank' : ''; ?>" class="btn btn-primary btn-sm">Cetak</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>  
