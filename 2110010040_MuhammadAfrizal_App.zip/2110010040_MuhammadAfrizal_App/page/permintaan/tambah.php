<?php 
$nomor = $_GET['nomor']; 
?>

<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>

<!--page title-->
<div class="page-title mb-4 d-flex align-items-center row">
    <div class="col-md-6 mb-2">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Tambah Data Permintaan</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li> 
                <li class="breadcrumb-item"><a href="#">Permintaan</a></li>
                <li class="breadcrumb-item active" aria-current="page">Tambah Data</li>
            </ol>
        </nav>
    </div> 
</div>
<!--/page title-->


<div class="tab-content" id="pills-tabContent">
    <div class="tab-pane fade show active" id="round-form" role="tabpanel" aria-labelledby="round-form-tab">
        <div class="row"> 
            <div class="col-md-12">
                <div class="card card-shadow mb-4">
                    <div class="card-header border-0">
                        <div class="custom-title-wrap bar-primary">
                            <div class="custom-title">Tambah Data Permintaan</div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form enctype="multipart/form-data" method="post" id="transaksiForm">
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Nomor</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="nomor" value="<?php echo $nomor ?>" readonly required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Hari</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="hari" required>
                                        <option selected disabled>Pilih</option>
                                        <option value="Senin">Senin</option>
                                        <option value="Selasa">Selasa</option>
                                        <option value="Rabu">Rabu</option>
                                        <option value="Kamis">Kamis</option>
                                        <option value="Jumat">Jumat</option>
                                        <option value="Sabtu">Sabtu</option>
                                        <option value="Minggu">Minggu</option>
                                    </select> 
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Tanggal</label>
                                <div class="col-sm-9">
                                    <input type="date" class="form-control" name="tanggal" value="<?php echo date('Y-m-d') ?>" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Nama</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="dari_nama" value="<?php echo $admin['nama'] ?>" readonly required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Unit Kerja</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="dari_unit" value="<?php echo $admin['unit_kerja'] ?>" readonly required>
                                </div>
                            </div> 
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">&nbsp;</label>
                                <div class="col-sm-9">
                                    <button name="simpan" class="btn btn-outline-primary rounded-0 btn-sm">Selesai, Lanjutkan</button>
                                    <a href="?page=permintaan" class="btn btn-outline-warning rounded-0 btn-sm"> Kembali</a>
                                </div>
                            </div>
                        </form> 
                        <?php 
                        if (isset($_POST['simpan'])) 
                        {
                            $nomor       = $_POST['nomor'];   
                            $hari        = $_POST['hari'];   
                            $tanggal     = $_POST['tanggal'];   
                            $dari_nama   = $_POST['dari_nama'];   
                            $dari_unit   = $_POST['dari_unit'];   

                            { 
                                $con->query("INSERT INTO minta (nomor,hari,tanggal,dari_nama,dari_unit,status) VALUES ('$nomor','$hari','$tanggal','$dari_nama','$dari_unit','Pending') ");
                                 
                                echo " 
                                <script>
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Berhasil!',
                                        text: 'Data berhasil disimpan!',
                                        timer: 1700,
                                        showConfirmButton: false
                                    }).then(function() {
                                        window.location = '?page=permintaan&aksi=ibarang&nomor=$nomor'; 
                                    });
                                </script>";
                            }
                        }
                        ?>
                    </div>
                </div> 
            </div>
        </div>
    </div> 
</div> 
