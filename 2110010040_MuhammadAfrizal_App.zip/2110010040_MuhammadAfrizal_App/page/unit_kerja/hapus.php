<!-- <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script> -->

<?php
$id_unit_kerja = $_GET['id_unit_kerja'];
$sql = $con->query("DELETE FROM unit_kerja WHERE id_unit_kerja='$id_unit_kerja'");

if ($sql) { 
    echo "
    
    <script>
        setTimeout(function() {
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: 'Data berhasil dihapus!',
                timer: 1700,
                showConfirmButton: false
            }).then(function() {
                window.location = '?page=unit_kerja';
            });
        }, 300);
    </script>";
} else { 
    echo " 
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Gagal!',
            text: 'Data gagal dihapus!',
        });
    </script>";
}
?>
