<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>

<!--page title-->
<div class="page-title mb-4 d-flex align-items-center row">
    <div class="col-md-6 mb-2">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Ubah Data Unit Kerja</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>
                <li class="breadcrumb-item"><a href="#">Data Master</a></li>
                <li class="breadcrumb-item"><a href="#">Unit Kerja</a></li>
                <li class="breadcrumb-item active" aria-current="page">Ubah Data</li>
            </ol>
        </nav>
    </div> 
</div>
<!--/page title-->

<?php
$id_unit_kerja = $_GET['id_unit_kerja'];
$sql = $con->query("SELECT * FROM unit_kerja WHERE id_unit_kerja='$id_unit_kerja'");
$data = mysqli_fetch_assoc($sql);
?>

<div class="tab-content" id="pills-tabContent">
    <div class="tab-pane fade show active" id="round-form" role="tabpanel" aria-labelledby="round-form-tab">
        <div class="row"> 
            <div class="col-md-12">
                <div class="card card-shadow mb-4">
                    <div class="card-header border-0">
                        <div class="custom-title-wrap bar-success">
                            <div class="custom-title">Ubah Data Unit Kerja</div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form enctype="multipart/form-data" method="post">
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Unit Kerja</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="unit_kerja" value="<?php echo $data['unit_kerja']; ?>" autofocus required >
                                </div>
                            </div>  
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">&nbsp;</label>
                                <div class="col-sm-9">
                                    <button name="simpan" class="btn btn-outline-success rounded-0 btn-sm">Ubah</button>
                                    <a href="?page=unit_kerja" class="btn btn-outline-warning rounded-0 btn-sm">Kembali</a>
                                </div>
                            </div>
                        </form>
                        <?php 
                        if (isset($_POST['simpan'])) 
                        {
                            $unit_kerja            = $_POST['unit_kerja'];    
                            
                            $con->query("UPDATE unit_kerja SET unit_kerja='$unit_kerja' WHERE id_unit_kerja='$id_unit_kerja'");

                            echo " 
                            <script>
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: 'Data berhasil diubah!',
                                    timer: 1700,
                                    showConfirmButton: false
                                }).then(function() {
                                    window.location = '?page=unit_kerja';
                                });
                            </script>";
                        }
                        ?>

                    </div>
                </div> 
            </div>
        </div>
    </div> 
</div> 
