<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Pengaturan</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li>
                <li class="breadcrumb-item"><a href="#">Data Master</a></li> 
                <li class="breadcrumb-item active" aria-current="page">Pengaturan</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<?php
$id_meta = $_GET['id_meta'];
$sql = $con->query("SELECT * FROM meta WHERE id_meta='$id_meta'");
$data = mysqli_fetch_assoc($sql);
?>

<div class="row">
    <div class="col-xl-3 col-md-6 profile-info-position"></div>
    <div class="col-xl-6 col-md-6 profile-info-position">
        <div class="card card-shadow mb-4">
            <div class="card-body">
                <div class="text-center">
                    <div class="mt-4 mb-3">
                        <img class="rounded-circle" src="assets/gambar/<?php echo $data['logo'] ?>" width="115px" alt=""/>
                    </div>
                    <h5 class="text-uppercase mb-0">
                        <?php echo $data['instansi']; ?>
                        <a href="?page=pengaturan&aksi=ubah&id_meta=<?php echo $data['id_meta'] ?>" data-toggle="tooltip" data-placement="top" title="Ubah data"><i class="icon icon-note"></i></a> 
                    </h5>
                    <p class="text-muted mb-0"><?php echo $data['alamat']; ?> </p> 
                </div>
                <br>
                <div class="row f12 mb-3">
                    <div class="col-6">Intansi</div>
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12"><?php echo $data['instansi']; ?></div> 
                        </div>
                    </div>
                </div>
                <div class="row f12 mb-3">
                    <div class="col-6">Pimpinan / Direktur Utama</div>
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12"><?php echo $data['pimpinan']; ?></div> 
                        </div>
                    </div>
                </div> 
                <div class="row f12 mb-3">
                    <div class="col-6">Telepon</div>
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12"><?php echo $data['telp']; ?></div> 
                        </div>
                    </div>
                </div>
                <div class="row f12 mb-3">
                    <div class="col-6">Email</div>
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12"><?php echo $data['email']; ?></div> 
                        </div>
                    </div>
                </div>
                <div class="row f12 mb-3">
                    <div class="col-6">Alamat</div>
                    <div class="col-6">
                        <div class="row">
                            <div class="col-12"><?php echo $data['alamat']; ?></div> 
                        </div>
                    </div>
                </div> 
            </div>
        </div> 
    </div> 
    <div class="col-xl-3 col-md-6 profile-info-position"></div>
</div>
