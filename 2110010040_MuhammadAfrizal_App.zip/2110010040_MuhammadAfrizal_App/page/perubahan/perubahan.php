<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>


<!--page title-->
<div class="page-title mb-4 d-flex align-items-center">
    <div class="mr-auto">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Perubahan Harga Barang</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li> 
                <li class="breadcrumb-item active" aria-current="page">Perubahan Harga</li>
            </ol>
        </nav>
    </div>
</div>
<!--/page title-->

<div class="row">
    <div class="col-xl-12">
        <div class="card card-shadow mb-4">
            <div class="card-header border-0">
                <div class="custom-title-wrap bar-primary">
                    <div class="custom-title">Data Perubahan Harga Barang
                        <div class="float-right" style="vertical-align: top;"> 
                            <a href="?page=perubahan&aksi=tambah" class="btn btn-outline-primary rounded-0 btn-sm" data-toggle="tooltip" data-placement="top" title="Tambah data"><i class="ti-plus"></i></a>   
                        </div>
                    </div>                    
                </div>
            </div>
            <div class="card-body pt-3 pb-4">
                <div class="table-responsive">
                    <?php  
                    $query_barang = $con->query("SELECT id_barang, kode, nama, tgl_input FROM barang ORDER BY id_barang ASC");

                    if (!$query_barang) {
                        die("Query gagal: " . $con->error);
                    }
                    ?>
                    <table id="data_table" class="table table-bordered table-striped" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="3%">No.</th>
                                <th class="text-center">Kode</th>  
                                <th>Nama</th> 
                                <th class="text-center">Tanggal Input</th>
                                <th>Riwayat Perubahan Harga</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $nomor = 1;
                            while ($barang = $query_barang->fetch_assoc()) {
                                $tgl_input = !empty($barang['tgl_input']) ? tgl_indo($barang['tgl_input']) : "Tanggal belum diinput";
                                ?>
                                <tr> 
                                    <td class="text-center"><?php echo $nomor; ?></td>  
                                    <td class="text-center"><?php echo $barang['kode']; ?></td>    
                                    <td><?php echo $barang['nama']; ?></td>    
                                    <td class="text-center"><?php echo $tgl_input; ?></td> 
                                    <td>
                                        <table id="hargaTable" class="table table-sm table-bordered shadow">
                                            <thead>
                                                <tr>
                                                    <th class="text-right">Harga Lama</th>
                                                    <th class="text-right">Harga Baru</th>
                                                    <th class="text-center">Tanggal Update</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                $query_perubahan = $con->query("SELECT harga_lama, harga_baru, tgl_update FROM perubahan WHERE id_barang = '{$barang['id_barang']}' ORDER BY tgl_update DESC");

                                                if ($query_perubahan && $query_perubahan->num_rows > 0) {
                                                    while ($perubahan = $query_perubahan->fetch_assoc()) {
                                                        $tgl_update = tgl_indo($perubahan['tgl_update']);
                                                        ?>
                                                        <tr>
                                                            <td class="text-right"><?php echo number_format($perubahan['harga_lama'], 0, ',', '.'); ?></td>
                                                            <td class="text-right"><?php echo number_format($perubahan['harga_baru'], 0, ',', '.'); ?></td>
                                                            <td class="text-center"><?php echo $tgl_update; ?></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                } else {
                                                    echo '<tr><td colspan="3" class="text-center">Belum ada perubahan harga untuk barang ini.</td></tr>';
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr> 
                                <?php 
                                $nomor++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>  

<script>
    $(document).ready(function() {
        $('#hargaTable').DataTable({
            "paging": true,          
            "lengthChange": false,   
            "searching": false,       
            "ordering": true,        
            "info": true,           
            "autoWidth": false,      
            "language": {
                "search": "Cari:",     
                "lengthMenu": "Tampilkan _MENU_ entri per halaman",
                "info": "Menampilkan _START_ hingga _END_ dari _TOTAL_ entri",
                "infoEmpty": "Tidak ada entri yang tersedia",
                "infoFiltered": "(disaring dari _MAX_ total entri)"
            }
        });
    });
</script>