<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script> 
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" /> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>


<!--page title-->
<div class="page-title mb-4 d-flex align-items-center row">
    <div class="col-md-6 mb-2">
        <h4 class="weight500 d-inline-block pr-3 mr-3 border-right">Tambah Data Perubahan Harga Barang</h4>
        <nav aria-label="breadcrumb" class="d-inline-block ">
            <ol class="breadcrumb p-0">
                <li class="breadcrumb-item"><a href="#">Beranda</a></li> 
                <li class="breadcrumb-item"><a href="#">Perubahan Harga </a></li>
                <li class="breadcrumb-item active" aria-current="page">Tambah Data</li>
            </ol>
        </nav>
    </div> 
</div>
<!--/page title-->


<div class="tab-content" id="pills-tabContent">
    <div class="tab-pane fade show active" id="round-form" role="tabpanel" aria-labelledby="round-form-tab">
        <div class="row"> 
            <div class="col-md-12">
                <div class="card card-shadow mb-4">
                    <div class="card-header border-0">
                        <div class="custom-title-wrap bar-primary">
                            <div class="custom-title">Tambah Data Perubahan Harga Barang</div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form enctype="multipart/form-data" method="post">
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Barang</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="id_barang" id="id_barang" required onchange="getHarga()">
                                        <option selected disabled>Pilih</option>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM barang ");
                                        while ($kar = mysqli_fetch_array($sql))
                                        {
                                            echo "<option value='$kar[id_barang]'>$kar[kode] - $kar[nama]</option>";
                                        }
                                        ?>
                                    </select> 
                                </div>
                            </div>   

                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Harga Lama</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="harga" id="harga" readonly required >
                                </div>
                            </div>  

                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">Harga Baru</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control" name="harga_baru" id="harga_baru" onkeypress="return angka(event);" required >
                                </div>
                            </div> 
                            <input type="date" class="form-control" name="tgl_update" hidden value="<?php echo date('Y-m-d') ?>" required > 
                            <div class="form-group row">
                                <label class="col-sm-3 col-form-label text-right">&nbsp;</label>
                                <div class="col-sm-9">
                                    <button name="simpan" class="btn btn-outline-primary rounded-0 btn-sm">Simpan</button>
                                    <a href="?page=perubahan" class="btn btn-outline-warning rounded-0 btn-sm"> Kembali</a>
                                </div>
                            </div>
                        </form>
                        <?php 
                        if (isset($_POST['simpan'])) 
                        {
                            $id_barang           = $_POST['id_barang'];
                            $tgl_update           = $_POST['tgl_update'];  
                            $harga1         = $_POST['harga'];
                            $harga          = str_replace(".", "", $harga1);
                            $harga_lama1         = $_POST['harga_lama'];
                            $harga_lama          = str_replace(".", "", $harga_lama1);
                            $harga_baru1         = $_POST['harga_baru'];
                            $harga_baru          = str_replace(".", "", $harga_baru1);     
                            
                             
                            $con->query("INSERT INTO perubahan (id_barang,tgl_update,harga_lama,harga_baru) VALUES ('$id_barang','$tgl_update','$harga','$harga_baru') ");

                            $con->query("UPDATE barang SET harga='$harga_baru' WHERE id_barang='$id_barang'"); 
                             
                            echo " 
                            <script>
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Berhasil!',
                                    text: 'Data berhasil disimpan!',
                                    timer: 1700,
                                    showConfirmButton: false
                                }).then(function() {
                                    window.location = '?page=perubahan';
                                });
                            </script>";
                            
                        }
                        ?>

                    </div>
                </div> 
            </div>
        </div>
    </div> 
</div>

<script>
    $(document).ready(function() {
        $('#id_barang').select2({
            placeholder: "Pilih barang",
            allowClear: true
        });
    });
</script>

<script>
function getHarga() {
    var id_barang = document.getElementById("id_barang").value;

    if(id_barang) { 
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "get_harga.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                document.getElementById("harga").value = xhr.responseText;
            }
        };
        xhr.send("id_barang="+id_barang);
    }
}
</script>

<script type="text/javascript">
    function angka(evt) 
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57)) 
        {
            return false;
        }
        return true;
    }
 

    var harga = document.getElementById('harga');
    harga.addEventListener('keyup', function(e)
    {
        harga.value = formatRupiah(this.value);
    });

    var harga_baru = document.getElementById('harga_baru');
    harga_baru.addEventListener('keyup', function(e)
    {
        harga_baru.value = formatRupiah(this.value);
    });  

    var harga_lama = document.getElementById('harga_lama');
    harga_lama.addEventListener('keyup', function(e)
    {
        harga_lama.value = formatRupiah(this.value);
    }); 
    
    /* Fungsi */
    function formatRupiah(angka, prefix)
    {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split    = number_string.split(','),
            sisa     = split[0].length % 3,
            rupiah     = split[0].substr(0, sisa),
            ribuan     = split[0].substr(sisa).match(/\d{3}/gi);
            
        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }
        
        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    } 
</script> 