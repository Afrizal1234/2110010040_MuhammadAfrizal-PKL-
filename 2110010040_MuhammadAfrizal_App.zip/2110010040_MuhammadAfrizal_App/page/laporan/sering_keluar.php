<?php
$nama_dokumen = 'LAPORAN BARANG YANG SERING KELUAR';
define('_MPDF_PATH', 'mpdf/');
include(_MPDF_PATH . "mpdf.php");
$mpdf = new mPDF('utf-8', 'A4');
ob_start();
include "../../inc/koneksi.php";
include "../../inc/tanggal.php";
?>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <title><?php echo $meta['instansi'] ?></title>
    <link rel="icon" type="image/png" href="mpdf/logo.png">
    <link rel="icon" href="mpdf/logo.png"> 
    <style>
        .horizontal_center
        {
            border-top: 2px solid black;
            height: 5px; 
        }
    </style>
</head>

<body>
    <table align="center">
        <tr align="center">
            <td align="center">
                <img src="mpdf/logo-sm.png" width="17%" height="15%">
                <p style="font-size: 16px; text-transform: uppercase;"><b><?php echo $meta['instansi'] ?> (PERSERODA)</b></p>
                <p style="font-size: 12px;">
                    Alamat : <?php echo $meta['alamat'] ?> <br>
                    Email : <?php echo $meta['email'] ?> | Telp : <?php echo $meta['telp'] ?>
                </p>
            </td>
        </tr>
    </table>

    <p class="horizontal_center"></p> 

    <p align="center"><b>LAPORAN BARANG YANG SERING KELUAR</b></p>

    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold;">No</td> 
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold;">Kode</td>
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold;">Nama Barang</td>
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: center;">Merk</td>
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: center;">Kategori</td>
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: center;">Bulan</td>
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: center;">Tahun</td>
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: center;" width="15%">Jumlah Keluar</td>
        </tr>
        <?php 
        $nomor = 1;  
        $ambil = $con->query("
            SELECT 
                b.kode AS kode,
                b.nama AS nama,
                m.merk AS merk,
                k.kategori AS kategori,
                MONTH(minta.tgl_keluar) AS bulan,
                YEAR(minta.tgl_keluar) AS tahun,
                SUM(md.qty) AS jumlah_keluar
            FROM 
                minta_detail md
            JOIN 
                barang b ON md.id_barang = b.id_barang
            JOIN 
                merk m ON b.id_merk = m.id_merk
            JOIN 
                kategori k ON b.id_kategori = k.id_kategori
            JOIN 
                minta ON md.nomor = minta.nomor
            WHERE 
                minta.status = 'Sudah diambil'
            GROUP BY 
                b.kode, b.nama, m.merk, k.kategori, MONTH(minta.tgl_keluar), YEAR(minta.tgl_keluar)
            ORDER BY 
                jumlah_keluar DESC
        ");
         
        while ($pecah = $ambil->fetch_assoc()) { 
            $bln = getBulan($pecah['bulan']);
        ?>
            <tr>
                <td style="font-size: 12px; border: 1px solid #999; padding: 2px;"><?php echo $nomor; ?></td> 
                <td style="font-size: 12px; border: 1px solid #999; padding: 2px;"><?php echo $pecah['kode']; ?></td>    
                <td style="font-size: 12px; border: 1px solid #999; padding: 2px;"><?php echo $pecah['nama']; ?></td>    
                <td style="font-size: 12px; border: 1px solid #999; padding: 2px; text-align: center"><?php echo $pecah['merk']; ?></td>      
                <td style="font-size: 12px; border: 1px solid #999; padding: 2px; text-align: center"><?php echo $pecah['kategori']; ?></td>      
                <td style="font-size: 12px; border: 1px solid #999; padding: 2px; text-align: center"><?php echo $bln; ?></td>       
                <td style="font-size: 12px; border: 1px solid #999; padding: 2px; text-align: center"><?php echo $pecah['tahun']; ?></td> 
                <td style="font-size: 12px; border: 1px solid #999; padding: 2px; text-align: center"><?php echo number_format($pecah['jumlah_keluar'], 0, ',', '.'); ?></td>
            </tr>
        <?php $nomor++;
        $total += $pecah['jumlah_keluar'];         } ?>
        <tr>
            <th colspan="7" style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: center;">Total Barang Yang Sering Keluar</th>
            <th  style="font-size: 12px; border: 1px solid #999; padding: 2px; text-align: center;"><?php echo $total; ?></th> <!-- Tampilkan grand total -->
        </tr>
    </table>

    <table align="right" style="margin-top: 20px;">
        <tr>
            <th style="font-size: 12px">Banjarbaru, <?php echo tgl_indo(date('Y-m-d')); ?></th>
        </tr>
        <tr>
            <th style="font-size: 12px">Pimpinan</th>
        </tr>
        <tr>
            <th>&nbsp;</th>
        </tr>
        <tr>
            <th>&nbsp;</th>
        </tr>
        <tr>
            <th align="center" style="font-size: 12px"><u><?php echo $meta['pimpinan'] ?></u></th>
        </tr>
    </table>
    <br />
</body>

<?php
$html = ob_get_contents();  
ob_end_clean();
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output($nama_dokumen . ".pdf", 'I');
exit;
?>
