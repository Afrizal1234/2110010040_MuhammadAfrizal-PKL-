<?php
$nama_dokumen = 'LAPORAN REKAPITULASI PERMINTAAN BARANG';
define('_MPDF_PATH', 'mpdf/');
include(_MPDF_PATH . "mpdf.php");
$mpdf = new mPDF('utf-8', 'A4');
ob_start();
include "../../inc/koneksi.php";
include "../../inc/tanggal.php";
?>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
    <title><?php echo $meta['instansi'] ?></title>
    <link rel="icon" type="image/png" href="mpdf/logo.png">
    <link rel="icon" href="mpdf/logo.png"> 
    <style>
        .horizontal_center
        {
            border-top: 2px solid black;
            height: 5px; 
        }
    </style>
</head>

<body>
    <table align="center">
        <tr align="center">
            <td align="center">
                <img src="mpdf/logo-sm.png" width="17%" height="15%">
                <p style="font-size: 16px; text-transform: uppercase;"><b><?php echo $meta['instansi'] ?> (PERSERODA)</b></p>
                <p style="font-size: 12px;">
                    Alamat : <?php echo $meta['alamat'] ?> <br>
                    Email : <?php echo $meta['email'] ?> | Telp : <?php echo $meta['telp'] ?>
                </p>
            </td>
        </tr>
    </table>

    <p class="horizontal_center"></p> 

    <p align="center"><b>LAPORAN REKAPITULASI PERMINTAAN BARANG</b></p>

    <table style="width: 100%; border-collapse: collapse;">
        <tr>
            <th style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold;">No.</th>
            <th style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold;">Nota</th>
            <th style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold;">Hari, Tanggal</th>
            <th style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold;">Dari</th> 
            <th style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold;">Unit Kerja</th> 
            <th style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: center;">Status</th> 
            <th style="font-size: 12px; border: 1px solid #999; padding: 2px; font-weight: bold; text-align: right;">Total</th> 
        </tr> 
        <?php $nomor=1; ?>
        <?php $ambil=$con->query("SELECT * FROM minta ORDER BY nomor ASC"); ?>
        <?php while ($pecah = $ambil->fetch_assoc()) { 
            $tgl = tgl_indo($pecah['tanggal']); ?>
        <tr> 
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px;"><?php echo $nomor; ?></td>  
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px;"><?php echo $pecah['nomor']; ?></td>    
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px;"><?php echo $pecah['hari']; ?>, <?php echo $tgl; ?></td>    
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px;"><?php echo $pecah['dari_nama']; ?></td>      
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px;"><?php echo $pecah['dari_unit']; ?></td>      
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; text-align: center"><?php echo $pecah['status']; ?></td>       
            <td style="font-size: 12px; border: 1px solid #999; padding: 2px; text-align: right"><?php echo number_format($pecah['gtotal'], 0, ',','.') ?></td> 
        </tr> 
        <?php $nomor++; ?>
        <?php } ?> 
    </table>

    <table align="right" style="margin-top: 20px;">
        <tr>
            <th style="font-size: 12px">Banjarbaru, <?php echo tgl_indo(date('Y-m-d')); ?></th>
        </tr>
        <tr>
            <th style="font-size: 12px">Pimpinan</th>
        </tr>
        <tr>
            <th>&nbsp;</th>
        </tr>
        <tr>
            <th>&nbsp;</th>
        </tr>
        <tr>
            <th align="center" style="font-size: 12px"><u><?php echo $meta['pimpinan'] ?></u></th>
        </tr>
    </table>
    <br />
</body>

<?php
$html = ob_get_contents(); 
ob_end_clean();
$mpdf->WriteHTML(utf8_encode($html));
$mpdf->Output($nama_dokumen . ".pdf", 'I');
exit;
?>
